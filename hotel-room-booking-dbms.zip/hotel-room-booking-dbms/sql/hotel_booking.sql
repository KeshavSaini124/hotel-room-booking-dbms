-- ####1 | Creating the database tables (DDL)
PRAGMA foreign_keys = ON;

CREATE TABLE guest (
    guest_id   INTEGER PRIMARY KEY,
    full_name  TEXT NOT NULL,
    phone      TEXT NOT NULL UNIQUE,
    email      TEXT,
    city       TEXT
);

CREATE TABLE room_type (
    type_id         INTEGER PRIMARY KEY,
    type_name       TEXT NOT NULL UNIQUE,
    price_per_night INTEGER NOT NULL CHECK (price_per_night > 0),
    capacity        INTEGER NOT NULL
);

CREATE TABLE room (
    room_no  INTEGER PRIMARY KEY,
    floor_no INTEGER NOT NULL,
    type_id  INTEGER NOT NULL REFERENCES room_type(type_id),
    status   TEXT NOT NULL DEFAULT 'Available'
             CHECK (status IN ('Available','Occupied','Maintenance'))
);

CREATE TABLE booking (
    booking_id INTEGER PRIMARY KEY,
    guest_id   INTEGER NOT NULL REFERENCES guest(guest_id),
    room_no    INTEGER NOT NULL REFERENCES room(room_no),
    check_in   TEXT NOT NULL,
    check_out  TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'Booked'
               CHECK (status IN ('Booked','Checked-In','Checked-Out','Cancelled')),
    CHECK (check_out > check_in)
);

CREATE TABLE payment (
    payment_id INTEGER PRIMARY KEY,
    booking_id INTEGER NOT NULL REFERENCES booking(booking_id),
    amount     INTEGER NOT NULL CHECK (amount > 0),
    method     TEXT NOT NULL CHECK (method IN ('Cash','Card','UPI')),
    paid_on    TEXT NOT NULL
);

SELECT name AS table_name FROM sqlite_master WHERE type = 'table' ORDER BY name;

-- ####2 | Inserting sample data (DML)
INSERT INTO room_type VALUES
  (1,'Standard',2500,2),(2,'Deluxe',4000,2),(3,'Family',5500,4),(4,'Suite',7500,3);

INSERT INTO room VALUES
  (101,1,1,'Available'),(102,1,1,'Available'),(103,1,1,'Maintenance'),
  (201,2,2,'Available'),(202,2,2,'Available'),(203,2,2,'Available'),
  (301,3,3,'Available'),(302,3,3,'Available'),
  (401,4,4,'Available'),(402,4,4,'Available');

INSERT INTO guest VALUES
  (1,'Keshav Saini','9812300001','keshav@example.com','Rohtak'),
  (2,'Aarav Sharma','9812300002','aarav@example.com','Delhi'),
  (3,'Priya Verma','9812300003','priya@example.com','Chandigarh'),
  (4,'Rohan Malhotra','9812300004','rohan@example.com','Ambala'),
  (5,'Sneha Kapoor','9812300005','sneha@example.com','Panipat'),
  (6,'Vikram Singh','9812300006','vikram@example.com','Jaipur'),
  (7,'Neha Gupta','9812300007','neha@example.com','Gurugram');

INSERT INTO booking VALUES
  (1,2,201,'2026-10-10','2026-10-13','Checked-Out'),
  (2,3,401,'2026-10-12','2026-10-15','Checked-Out'),
  (3,4,102,'2026-10-18','2026-10-21','Checked-In'),
  (4,5,301,'2026-10-19','2026-10-22','Checked-In'),
  (5,1,202,'2026-10-24','2026-10-26','Booked'),
  (6,6,402,'2026-10-25','2026-10-29','Booked'),
  (7,7,203,'2026-10-14','2026-10-16','Cancelled'),
  (8,2,101,'2026-10-27','2026-10-30','Booked');

INSERT INTO payment VALUES
  (1,1,12000,'Card','2026-10-13'),
  (2,2,22500,'UPI','2026-10-15'),
  (3,3,3000,'Cash','2026-10-18'),
  (4,4,8000,'UPI','2026-10-19'),
  (5,5,2000,'UPI','2026-10-20'),
  (6,6,5000,'Card','2026-10-20');

SELECT 'guest' AS table_name, COUNT(*) AS total_rows FROM guest
UNION ALL SELECT 'room_type', COUNT(*) FROM room_type
UNION ALL SELECT 'room', COUNT(*) FROM room
UNION ALL SELECT 'booking', COUNT(*) FROM booking
UNION ALL SELECT 'payment', COUNT(*) FROM payment;

-- ####3 | Viewing rooms with their type (INNER JOIN)
SELECT r.room_no, r.floor_no, t.type_name, t.price_per_night AS price, t.capacity, r.status
FROM room r
JOIN room_type t ON t.type_id = r.type_id
ORDER BY r.room_no;

-- ####4 | Searching available rooms for a date range (NOT EXISTS)
SELECT r.room_no, t.type_name, t.price_per_night AS price
FROM room r
JOIN room_type t ON t.type_id = r.type_id
WHERE r.status <> 'Maintenance'
  AND NOT EXISTS (
        SELECT 1 FROM booking b
        WHERE b.room_no = r.room_no
          AND b.status IN ('Booked','Checked-In')
          AND b.check_in  < '2026-10-28'
          AND b.check_out > '2026-10-25')
ORDER BY r.room_no;

-- ####5 | Trigger to prevent double booking
CREATE TRIGGER trg_no_double_booking
BEFORE INSERT ON booking
WHEN EXISTS (
    SELECT 1 FROM booking b
    WHERE b.room_no = NEW.room_no
      AND b.status IN ('Booked','Checked-In')
      AND b.check_in  < NEW.check_out
      AND b.check_out > NEW.check_in)
BEGIN
    SELECT RAISE(ABORT, 'Room already booked for the selected dates');
END;

INSERT INTO booking (guest_id, room_no, check_in, check_out)
VALUES (3, 202, '2026-10-25', '2026-10-27');

INSERT INTO booking (guest_id, room_no, check_in, check_out)
VALUES (3, 203, '2026-10-25', '2026-10-27');

SELECT booking_id, guest_id, room_no, check_in, check_out, status
FROM booking WHERE booking_id > 8;

-- ####6 | View for booking details and bill calculation
CREATE VIEW v_booking_bill AS
SELECT b.booking_id,
       g.full_name AS guest,
       b.room_no,
       t.type_name AS room_type,
       CAST(julianday(b.check_out) - julianday(b.check_in) AS INTEGER) AS nights,
       CAST(julianday(b.check_out) - julianday(b.check_in) AS INTEGER) * t.price_per_night AS bill,
       COALESCE((SELECT SUM(p.amount) FROM payment p WHERE p.booking_id = b.booking_id), 0) AS paid,
       b.status
FROM booking b
JOIN guest g     ON g.guest_id = b.guest_id
JOIN room r      ON r.room_no  = b.room_no
JOIN room_type t ON t.type_id  = r.type_id;

SELECT * FROM v_booking_bill ORDER BY booking_id;

-- ####7 | Pending payments (using the view)
SELECT booking_id, guest, bill, paid, bill - paid AS balance
FROM v_booking_bill
WHERE status <> 'Cancelled' AND bill > paid
ORDER BY balance DESC;

-- ####8 | Revenue report by room type (GROUP BY)
SELECT t.type_name,
       COUNT(b.booking_id) AS bookings,
       SUM(v.bill)         AS total_billed
FROM room_type t
JOIN room r         ON r.type_id = t.type_id
JOIN booking b      ON b.room_no = r.room_no AND b.status <> 'Cancelled'
JOIN v_booking_bill v ON v.booking_id = b.booking_id
GROUP BY t.type_name
ORDER BY total_billed DESC;

-- ####9 | Check-out, cancellation and room status update (UPDATE)
UPDATE booking SET status = 'Checked-Out' WHERE booking_id = 3;
UPDATE booking SET status = 'Cancelled'   WHERE booking_id = 6;
UPDATE room SET status = 'Occupied'
WHERE room_no IN (SELECT room_no FROM booking WHERE status = 'Checked-In');

SELECT booking_id, guest, room_no, status FROM v_booking_bill ORDER BY booking_id;

SELECT room_no, status FROM room WHERE status <> 'Available';

-- ####10 | Guest-wise spending using GROUP BY, HAVING and a subquery
SELECT g.full_name, g.city, COUNT(DISTINCT b.booking_id) AS paid_stays, SUM(p.amount) AS total_paid
FROM guest g
JOIN booking b ON b.guest_id = g.guest_id
JOIN payment p ON p.booking_id = b.booking_id
GROUP BY g.guest_id
HAVING SUM(p.amount) > (SELECT AVG(amount) FROM payment)
ORDER BY total_paid DESC;
