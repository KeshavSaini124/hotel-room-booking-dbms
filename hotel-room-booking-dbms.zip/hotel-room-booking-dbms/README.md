# Hotel Room Booking System (DBMS Mini Project)

Mini project for Database Management System, Chandigarh University.
Submitted by Keshav Saini (UID 25BCD10101, Section 25BCD2) to Mrs. Harkamal Kaur, Assistant Professor.

A relational database for a hotel: guests, room types, rooms, bookings and payments, with
constraints, a double-booking trigger, a billing view and report queries.

## Files
| Path | Purpose |
|---|---|
| `sql/hotel_booking.sql` | Full SQL: tables, data, queries, trigger, view |
| `run_sql.py` | Runs the SQL step by step and prints the output (writes `output/*.txt`) |
| `make_screens.py` | Turns the output into terminal-style screenshots (needs Pillow) |
| `docs/` | ER diagram, screenshots and the project report (.docx / .pdf) |

## Run
```
python3 run_sql.py output
```
Tested with Python 3 and SQLite 3.45 (no extra packages needed).

## Tables
`guest`, `room_type`, `room`, `booking`, `payment` and the view `v_booking_bill`.
