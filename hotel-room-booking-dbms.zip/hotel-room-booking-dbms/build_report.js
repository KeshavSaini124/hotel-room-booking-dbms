const fs = require('fs');
const path = require('path');
const { Document, Packer, Paragraph, TextRun, ImageRun, Header, Footer, Table, TableRow, TableCell,
  AlignmentType, WidthType, ShadingType, BorderStyle, LevelFormat, PageNumber, TabStopType, LeaderType,
  PageBreak } = require('docx');

const OUT = process.argv[2] || 'docs/Hotel_Room_Booking_System_DBMS_Mini_Project.docx';
const PAGES = fs.existsSync('docs/.pages.json') ? JSON.parse(fs.readFileSync('docs/.pages.json')) : {};
const RED = 'B71C1C', W = 9900;

const pngSize = f => { const b = fs.readFileSync(f); return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) }; };
const T = (text, o = {}) => new TextRun({ text, font: 'Times New Roman', size: 24, ...o });
const P = (text, o = {}) => new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 140, line: 300 },
  children: Array.isArray(text) ? text : [T(text)], ...o });
const H1 = (text, brk = true) => new Paragraph({ keepNext: true, pageBreakBefore: brk, spacing: { before: 0, after: 200 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: RED, space: 4 } },
  children: [new TextRun({ text, font: 'Arial', size: 30, bold: true, color: RED })] });
const H2 = text => new Paragraph({ keepNext: true, spacing: { before: 220, after: 100 },
  children: [new TextRun({ text, font: 'Arial', size: 25, bold: true, color: '7A1010' })] });
const bullet = text => new Paragraph({ numbering: { reference: 'b', level: 0 }, alignment: AlignmentType.JUSTIFIED,
  spacing: { after: 80, line: 290 }, children: Array.isArray(text) ? text : [T(text)] });
const B = s => T(s, { bold: true });
const center = (text, o = {}) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: o.after ?? 120 },
  children: [T(text, o)] });

const bd = { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' };
const borders = { top: bd, bottom: bd, left: bd, right: bd };
function table(widths, head, rows) {
  const cell = (t, w, hd) => new TableCell({ width: { size: w, type: WidthType.DXA }, borders,
    shading: hd ? { fill: RED, type: ShadingType.CLEAR, color: 'auto' } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new Paragraph({ children: [new TextRun({ text: t, font: 'Times New Roman', size: 22,
      bold: hd, color: hd ? 'FFFFFF' : '000000' })] })] });
  return new Table({ width: { size: widths.reduce((a, b) => a + b), type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ tableHeader: true, children: head.map((h, i) => cell(h, widths[i], true)) }),
      ...rows.map(r => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, widths[i], false)) }))] });
}
function img(file, maxPx = 640, scale = 0.78) {
  const { w, h } = pngSize(file);
  const k = Math.min(scale, maxPx / w);
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 160 },
    children: [new ImageRun({ type: 'png', data: fs.readFileSync(file),
      transformation: { width: Math.round(w * k), height: Math.round(h * k) },
      altText: { title: path.basename(file), description: 'Terminal output screenshot', name: path.basename(file) } })] });
}
const caption = t => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 },
  children: [T(t, { italics: true, size: 20 })] });

// ---------- Cover ----------
const cover = [
  new Paragraph({ spacing: { before: 700, after: 160 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Hotel Room Booking System', font: 'Times New Roman', size: 48, bold: true, color: '1F3864' })] }),
  center('Database Management System (DBMS) – Mini Project', { size: 28, after: 120 }),
  center('A MINI PROJECT REPORT', { bold: true, size: 26, after: 500 }),
  center('Submitted by:', { italics: true, after: 80 }),
  center('Keshav Saini', { bold: true, size: 30, after: 40 }),
  center('UID: 25BCD10101', { size: 26, after: 40 }),
  center('Section: 25BCD2', { size: 26, after: 460 }),
  center('Submitted to:', { italics: true, after: 80 }),
  center('Name: Mrs. Harkamal Kaur', { bold: true, size: 28, after: 40 }),
  center('Designation: Assistant Professor', { bold: true, size: 26, after: 460 }),
  center('in partial fulfillment for the award of the degree of', { italics: true, size: 22 }),
  center('BACHELOR OF COMPUTER APPLICATIONS (HONOURS)', { bold: true, size: 26, after: 40 }),
  center('IN', { bold: true, size: 22, after: 40 }),
  center('DATA SCIENCE', { size: 24, after: 320 }),
  center('Chandigarh University', { bold: true, size: 26, after: 40 }),
  center('Date of Submission: 21 October 2026', { size: 24 }),
];

// ---------- Contents ----------
const tocItems = [
  ['1. Introduction', 'INTRO'], ['2. Objectives / Problem Statement', 'OBJ'],
  ['3. Modules, Tools and Technologies Used', 'MOD'], ['4. Code with Output', 'CODE'],
  ['5. Conclusion', 'CONC'], ['References', 'REF'],
];
const toc = [
  new Paragraph({ pageBreakBefore: true, spacing: { after: 300 }, alignment: AlignmentType.CENTER,
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: RED, space: 4 } },
    children: [new TextRun({ text: 'TABLE OF CONTENTS', font: 'Arial', size: 30, bold: true, color: RED })] }),
  ...tocItems.map(([t, k]) => new Paragraph({ spacing: { after: 200 },
    tabStops: [{ type: TabStopType.RIGHT, position: W, leader: LeaderType.DOT }],
    children: [T(t, { size: 26 }), T('\t' + (PAGES[k] || ''), { size: 26 })] })),
  new Paragraph({ spacing: { before: 300, after: 100 }, children: [T('Code listing – steps in Chapter 4', { bold: true })] }),
  ...[ '4.1 Creating the database tables (DDL)', '4.2 Inserting sample data (DML)', '4.3 Viewing rooms with their type (INNER JOIN)',
    '4.4 Searching available rooms for a date range (NOT EXISTS)', '4.5 Trigger to prevent double booking',
    '4.6 View for booking details and bill calculation', '4.7 Pending payments', '4.8 Revenue report by room type (GROUP BY)',
    '4.9 Check-out, cancellation and room status update (UPDATE)', '4.10 Guest-wise spending using GROUP BY, HAVING and a subquery']
    .map((t, i) => new Paragraph({ spacing: { after: 90 }, indent: { left: 360 },
      tabStops: [{ type: TabStopType.RIGHT, position: W, leader: LeaderType.DOT }],
      children: [T(t, { size: 23 }), T('\t' + (PAGES['S' + (i + 1)] || ''), { size: 23 })] })),
];

// ---------- Chapter 1 ----------
const ch1 = [
  H1('1. INTRODUCTION'),
  H2('1.1 Background'),
  P('A hotel handles a continuous stream of information – guest details, room inventory, reservations, check-ins, check-outs and payments. When this information is kept in paper registers or scattered spreadsheets, it is easy to lose records, to book the same room twice, or to miscalculate a guest’s bill. A Database Management System (DBMS) stores all of this data in one organised place, enforces rules on it, and lets the staff retrieve exactly what they need with a single query.'),
  H2('1.2 About the project'),
  P([B('Hotel Room Booking System'), T(' is a mini project built for the Database Management System course. It is a relational database that models the day-to-day working of a hotel front desk: registering guests, maintaining rooms and room categories, searching for rooms that are free on given dates, making and cancelling bookings, generating bills and recording payments.')]),
  P('The database is designed around five related tables (guest, room_type, room, booking and payment) that are linked through primary keys and foreign keys. Business rules such as “the check-out date must be after the check-in date” and “a room cannot be booked twice for overlapping dates” are enforced by the database itself through CHECK constraints and a trigger, so wrong data cannot be entered even by mistake.'),
  H2('1.3 Scope'),
  P('The project covers the design and implementation of the database and the SQL operations needed by a hotel: data definition (DDL), data manipulation (DML), joins, sub-queries, aggregate reports, views and triggers. A graphical front-end is outside the scope of this mini project; every operation is demonstrated directly in the SQL shell and its real output is shown in Chapter 4.'),
];

// ---------- Chapter 2 ----------
const ch2 = [
  H1('2. OBJECTIVES / PROBLEM STATEMENT'),
  H2('2.1 Problem statement'),
  P('Small and medium hotels often manage reservations manually. This leads to the following problems: (i) the same room being allotted to two guests for overlapping dates, (ii) no quick way to find which rooms are free for a given period, (iii) errors in calculating the bill for a stay, (iv) difficulty in tracking balance payments, and (v) no consolidated report of revenue or guest history. The problem is to design a reliable relational database that removes these difficulties and keeps the data consistent and easy to query.'),
  H2('2.2 Objectives'),
  bullet('To design a normalised relational schema for a hotel with proper primary keys, foreign keys and constraints.'),
  bullet('To store guest, room, room-category, booking and payment information without redundancy.'),
  bullet('To search the rooms that are available for any given check-in and check-out dates.'),
  bullet('To prevent double booking automatically using a database trigger.'),
  bullet('To calculate the number of nights, the bill and the pending balance of every booking using a view.'),
  bullet('To generate management reports such as revenue by room type and guest-wise spending.'),
  bullet('To demonstrate DDL, DML, joins, sub-queries, GROUP BY / HAVING, views and triggers with real output.'),
];

// ---------- Chapter 3 ----------
const ch3 = [
  H1('3. MODULES, TOOLS AND TECHNOLOGIES USED'),
  H2('3.1 Modules of the system'),
  table([600, 2700, 6600], ['No.', 'Module', 'Description'], [
    ['1', 'Guest Management', 'Stores guest name, unique phone number, e-mail and city. Table: guest.'],
    ['2', 'Room Management', 'Keeps the room inventory with floor and status (Available / Occupied / Maintenance) and the room categories with price and capacity. Tables: room, room_type.'],
    ['3', 'Booking Management', 'Creates, updates and cancels reservations; finds free rooms for a date range; blocks overlapping bookings with a trigger. Table: booking.'],
    ['4', 'Billing and Payment', 'Calculates nights and bill from the room price, records payments (Cash / Card / UPI) and shows the pending balance. Table: payment and view v_booking_bill.'],
    ['5', 'Reports', 'Revenue by room type, pending payments, current room status and guest-wise spending using aggregate queries.'],
  ]),
  H2('3.2 Tools and technologies'),
  table([2700, 7200], ['Tool / Technology', 'Use in this project'], [
    ['SQL (Structured Query Language)', 'Language used for creating tables, inserting data, querying, views and triggers.'],
    ['SQLite 3.45', 'Relational database engine on which every query in this report was executed.'],
    ['Python 3 (sqlite3 module)', 'Small script (run_sql.py) that runs the SQL file step by step and prints the result in tabular form.'],
    ['Graphviz', 'Used to draw the ER diagram given in Section 3.3.'],
    ['Git and GitHub', 'Version control and online hosting of the project source code.'],
    ['Microsoft Word', 'Preparation of this project report.'],
  ]),
  H2('3.3 ER diagram'),
  P('The following diagram shows the tables and the one-to-many relationships between them. One room type has many rooms; one guest and one room can each have many bookings; one booking can have many payments (for example an advance and a final payment).'),
  img('docs/er_diagram.png', 640, 1),
  caption('Fig. 3.1 – ER diagram of the Hotel Room Booking System'),
  H2('3.4 Database design'),
  table([1700, 4300, 3900], ['Table', 'Columns', 'Keys and constraints'], [
    ['guest', 'guest_id, full_name, phone, email, city', 'PK guest_id; phone UNIQUE and NOT NULL'],
    ['room_type', 'type_id, type_name, price_per_night, capacity', 'PK type_id; type_name UNIQUE; price > 0'],
    ['room', 'room_no, floor_no, type_id, status', 'PK room_no; FK type_id; status CHECK (Available, Occupied, Maintenance)'],
    ['booking', 'booking_id, guest_id, room_no, check_in, check_out, status', 'PK booking_id; FK guest_id, room_no; check_out > check_in; status CHECK'],
    ['payment', 'payment_id, booking_id, amount, method, paid_on', 'PK payment_id; FK booking_id; amount > 0; method CHECK (Cash, Card, UPI)'],
  ]),
  P([T('The design is in Third Normal Form. Room price and capacity are stored once in '), B('room_type'), T(' instead of being repeated for every room, and the bill is never stored – it is derived from the number of nights and the room price in the view, so it can never become inconsistent with the booking.')], { spacing: { before: 160, after: 140, line: 300 } }),
];

// ---------- Chapter 4 ----------
const steps = [
  ['4.1 Creating the database tables (DDL)', 1, 'The CREATE TABLE statements define the five tables together with their primary keys, foreign keys and CHECK constraints. The last query lists the tables that now exist in the database.'],
  ['4.2 Inserting sample data (DML)', 2, 'Sample records for 4 room types, 10 rooms, 7 guests, 8 bookings and 6 payments are inserted. The final query counts the rows of every table to confirm the load.'],
  ['4.3 Viewing rooms with their type (INNER JOIN)', 3, 'Rooms are joined with room_type so that each room is displayed along with its category, price per night, capacity and current status.'],
  ['4.4 Searching available rooms for a date range (NOT EXISTS)', 4, 'Finds the rooms that are free from 25 to 28 October 2026. A room is excluded if it is under maintenance or has an active booking whose dates overlap with the requested period.'],
  ['4.5 Trigger to prevent double booking', 5, 'The trigger trg_no_double_booking aborts any insert that overlaps an existing active booking of the same room. Room 202 is already booked from 24 to 26 October, so the first insert is rejected with an error; the second insert, for the free room 203, succeeds and appears as booking 9.'],
  ['4.6 View for booking details and bill calculation', 6, 'The view v_booking_bill joins booking, guest, room and room_type and calculates nights, bill (nights × price per night) and the amount paid so far.'],
  ['4.7 Pending payments', 7, 'Using the view, the bookings whose bill is greater than the amount paid are listed with their balance, highest balance first. Cancelled bookings are ignored.'],
  ['4.8 Revenue report by room type (GROUP BY)', 8, 'Groups the non-cancelled bookings by room type and shows the number of bookings and the total billed amount of each category.'],
  ['4.9 Check-out, cancellation and room status update (UPDATE)', 9, 'Booking 3 is checked out, booking 6 is cancelled, and the rooms of all guests who are currently checked in are marked Occupied. The two queries afterwards show the new booking and room statuses.'],
  ['4.10 Guest-wise spending using GROUP BY, HAVING and a subquery', 10, 'Lists the guests whose total payment is more than the average payment, using GROUP BY, HAVING and a scalar sub-query.'],
];
const ch4 = [
  H1('4. CODE WITH OUTPUT'),
  P('The complete SQL code is kept in the file sql/hotel_booking.sql of the GitHub repository. Each step below shows the SQL statements exactly as they were typed at the prompt, followed by the output produced by the database engine.'),
];
steps.forEach(([title, n, desc], i) => {
  const files = fs.readdirSync('docs/screenshots').filter(f => f.startsWith('step' + String(n).padStart(2, '0') + '_')).sort();
  ch4.push(H2(title), P(desc, { keepNext: true }));
  files.forEach((f, k) => {
    ch4.push(img('docs/screenshots/' + f));
  });
  ch4.push(caption(`Output ${n} – ${title.replace(/^\d+\.\d+ /, '')}`));
});

// ---------- Chapter 5 ----------
const ch5 = [
  H1('5. CONCLUSION'),
  P('The Hotel Room Booking System demonstrates how a relational database can replace manual record keeping in a hotel. The five tables are linked through foreign keys, the data is kept consistent by constraints, and the trigger guarantees that a room can never be booked twice for overlapping dates. The view makes the bill and balance of every booking available with a single query, and the report queries give the management a clear picture of revenue and guest activity.'),
  P('While doing the project, the concepts of ER modelling, normalisation, primary and foreign keys, joins, sub-queries, aggregate functions, views and triggers were applied practically and tested with real data and real output.'),
  H2('5.1 Limitations'),
  bullet('The project has no graphical front-end; all operations are performed through SQL.'),
  bullet('It uses an embedded single-user database engine, so it is not meant for many simultaneous users.'),
  bullet('Taxes, discounts, meal plans and room service charges are not included in the bill.'),
  H2('5.2 Future scope'),
  bullet('A web or desktop front-end for the reception desk and an online booking page for guests.'),
  bullet('Staff, housekeeping and room-service tables, with role-based access.'),
  bullet('GST, discount and seasonal pricing support, and printable invoices.'),
  bullet('Migration to a client-server database such as MySQL or PostgreSQL for multi-user use.'),
  H1('REFERENCES', false),
  bullet('R. Elmasri and S. Navathe, Fundamentals of Database Systems, Pearson.'),
  bullet('A. Silberschatz, H. Korth and S. Sudarshan, Database System Concepts, McGraw-Hill.'),
  bullet('SQLite Documentation – https://www.sqlite.org/docs.html'),
  bullet('Project source code: GitHub repository hotel-room-booking-dbms (sql/hotel_booking.sql, run_sql.py).'),
];
// REFERENCES shares chapter-5 flow? keep separate page

// ---------- Document ----------
const logo = fs.readFileSync('docs/cu_logo.png');
const doc = new Document({
  creator: 'Keshav Saini', title: 'Hotel Room Booking System - DBMS Mini Project',
  styles: { default: { document: { run: { font: 'Times New Roman', size: 24 } } } },
  numbering: { config: [{ reference: 'b', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•',
    alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 },
      margin: { top: 1560, right: 999, bottom: 900, left: 1007, header: 280, footer: 400 } } },
    headers: { default: new Header({ children: [new Paragraph({ spacing: { after: 0 },
      children: [new ImageRun({ type: 'png', data: logo, transformation: { width: 215, height: 82 },
        altText: { title: 'Chandigarh University logo', description: 'Chandigarh University logo', name: 'cu_logo' } })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      border: { top: { style: BorderStyle.SINGLE, size: 4, color: 'AAAAAA', space: 4 } },
      children: [new TextRun({ text: 'Hotel Room Booking System  |  Keshav Saini (25BCD10101)  |  Page ', font: 'Arial', size: 17, color: '555555' }),
        new TextRun({ children: [PageNumber.CURRENT], font: 'Arial', size: 17, color: '555555' })] })] }) },
    children: [...cover, ...toc, ...ch1, ...ch2, ...ch3, ...ch4, ...ch5],
  }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log('wrote', OUT); });
