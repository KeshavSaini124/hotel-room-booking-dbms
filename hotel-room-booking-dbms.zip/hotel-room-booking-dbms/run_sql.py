"""Runs sql/hotel_booking.sql block by block and prints SQL + result in a
terminal-style transcript.  Usage:  python3 run_sql.py [out_dir]
Writes one .txt transcript per block into out_dir (default: output/)."""
import sqlite3, sys, re, os

SQL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sql", "hotel_booking.sql")
OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
os.makedirs(OUT, exist_ok=True)

def grid(cols, rows):
    rows = [["NULL" if v is None else str(v) for v in r] for r in rows]
    w = [max(len(c), *(len(r[i]) for r in rows)) if rows else len(c) for i, c in enumerate(cols)]
    sep = "+" + "+".join("-" * (x + 2) for x in w) + "+"
    def line(vals, num=None):
        return "|" + "|".join(" " + v.ljust(w[i]) + " " for i, v in enumerate(vals)) + "|"
    out = [sep, line(cols), sep] + [line(r) for r in rows] + [sep]
    return out

def split_blocks(text):
    parts = re.split(r"^-- ####(\d+) \| (.*)$", text, flags=re.M)
    return [(int(parts[i]), parts[i + 1].strip(), parts[i + 2]) for i in range(1, len(parts), 3)]

def statements(body):
    buf, out = "", []
    for ln in body.splitlines():
        if not buf and not ln.strip():
            continue
        buf += ln + "\n"
        if sqlite3.complete_statement(buf):
            out.append(buf.strip()); buf = ""
    return out

db = sqlite3.connect(":memory:", isolation_level=None)
for n, title, body in split_blocks(open(SQL).read()):
    lines = []
    for st in statements(body):
        sl = st.splitlines()
        lines.append("sqlite> " + sl[0])
        lines += ["   ...> " + x for x in sl[1:]]
        try:
            cur = db.execute(st)
            if cur.description:
                data = cur.fetchall()
                lines += grid([d[0] for d in cur.description], data)
                lines.append(f"{len(data)} row{'s' if len(data)!=1 else ''} in set")
            else:
                kind = st.split()[0].upper()
                if kind in ("INSERT", "UPDATE", "DELETE"):
                    lines.append(f"Query OK, {cur.rowcount} row(s) affected")
                else:
                    lines.append("Query OK")
        except sqlite3.Error as e:
            lines.append(f"Error: {e}")
        lines.append("")
    open(os.path.join(OUT, f"{n:02d}.txt"), "w").write(f"{title}\n" + "\n".join(lines))
print("done")
