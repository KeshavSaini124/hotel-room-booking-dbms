import subprocess, json, re, sys
pdf = sys.argv[1]
n = int(re.search(r'Pages:\s+(\d+)', subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout).group(1))
keys = {'INTRO': '1. INTRODUCTION', 'OBJ': '2. OBJECTIVES', 'MOD': '3. MODULES, TOOLS', 'CODE': '4. CODE WITH OUTPUT',
        'CONC': '5. CONCLUSION', 'REF': 'REFERENCES'}
titles = ['Creating the database tables (DDL)','Inserting sample data (DML)','Viewing rooms with their type (INNER JOIN)',
 'Searching available rooms for a date range (NOT EXISTS)','Trigger to prevent double booking',
 'View for booking details and bill calculation','Pending payments','Revenue report by room type (GROUP BY)',
 'Check-out, cancellation and room status update (UPDATE)','Guest-wise spending using GROUP BY']
for i, t in enumerate(titles, 1): keys[f'S{i}'] = f'4.{i} {t}'
out = {}
for p in range(3, n + 1):
    txt = re.sub(r'\s+', ' ', subprocess.run(['pdftotext', '-f', str(p), '-l', str(p), pdf, '-'], capture_output=True, text=True).stdout)
    for k, v in keys.items():
        if k not in out and v in txt: out[k] = p
print(n, out)
json.dump(out, open('docs/.pages.json', 'w'))
