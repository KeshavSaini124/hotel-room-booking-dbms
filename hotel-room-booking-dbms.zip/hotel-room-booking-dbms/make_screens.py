"""Turns output/*.txt transcripts into terminal-style PNG screenshots."""
import glob, os, sys
from PIL import Image, ImageDraw, ImageFont

FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 17)
BOLD = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 17)
CW = FONT.getlength("M"); LH = 24
BG, FG, PROMPT, ERR, TITLE = "#0c0c0c", "#cccccc", "#13a10e", "#e74856", "#1f1f1f"
MAXL = 34
os.makedirs(sys.argv[2], exist_ok=True)

def chunks(lines):
    out, cur = [], []
    for ln in lines:
        cur.append(ln)
        if ln == "" and len(cur) >= 14 or len(cur) >= MAXL:
            out.append(cur); cur = []
    if cur: out.append(cur)
    # drop trailing blank-only lines per chunk
    return [[l for l in c] if any(c) else c for c in out if any(x.strip() for x in c)]

for f in sorted(glob.glob(os.path.join(sys.argv[1], "*.txt"))):
    n = os.path.basename(f)[:2]
    title, *lines = open(f).read().split("\n")
    while lines and lines[-1] == "": lines.pop()
    for k, c in enumerate(chunks(lines), 1):
        while c and c[-1] == "": c.pop()
        w = int(max(len(l) for l in c) * CW) + 40
        w = max(w, 760)
        h = 38 + len(c) * LH + 24
        im = Image.new("RGB", (w, h), BG); d = ImageDraw.Draw(im)
        d.rectangle([0, 0, w, 34], fill=TITLE)
        for i, col in enumerate(("#ff5f56", "#ffbd2e", "#27c93f")):
            d.ellipse([14 + i * 22, 11, 26 + i * 22, 23], fill=col)
        d.text((100, 8), "hotel_booking.db  -  SQLite Shell", font=FONT, fill="#9a9a9a")
        y = 44
        for l in c:
            if l.startswith(("sqlite> ", "   ...> ")):
                d.text((20, y), l[:8], font=BOLD, fill=PROMPT)
                d.text((20 + 8 * CW, y), l[8:], font=FONT, fill="#f2f2f2")
            elif l.startswith("Error"):
                d.text((20, y), l, font=BOLD, fill=ERR)
            else:
                d.text((20, y), l, font=FONT, fill=FG)
            y += LH
        im.save(os.path.join(sys.argv[2], f"step{n}_{k}.png"))
print(len(os.listdir(sys.argv[2])), "screenshots")
